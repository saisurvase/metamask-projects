// Admin
export const SET_TOKEN = 'SET_TOKEN'

// Web
export const SET_WEB_USER_INFO = 'SET_WEB_USER_INFO'