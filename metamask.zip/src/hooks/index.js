import useFetchAPI from './useFetchAPI'
import useGetTokenIdAPI from './api/useGetTokenIdAPI'
import useGetIsRegisterAPI from './api/useGetIsRegisterAPI'

export { useFetchAPI, useGetTokenIdAPI, useGetIsRegisterAPI }