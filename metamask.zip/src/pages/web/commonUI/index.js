import FooterAndSearch from './FooterAndSearch'
import Header from './Header'
import Loader from './Loader'
import OffCanvasMenu from './OffCanvasMenu'

export { FooterAndSearch, Header, Loader, OffCanvasMenu }